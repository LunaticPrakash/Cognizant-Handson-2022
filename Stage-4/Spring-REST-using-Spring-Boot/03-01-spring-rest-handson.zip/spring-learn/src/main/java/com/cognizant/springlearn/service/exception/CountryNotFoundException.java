package com.cognizant.springlearn.service.exception;

public class CountryNotFoundException extends Exception{

	
	private static final long serialVersionUID = 1L;

	public  CountryNotFoundException(){
		super();
	}

}
