package com.example.jenkins;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JenkinsHandsOnApplicationTests {

	@Test
	void contextLoads() {
	}

}
