package com.example.jenkins;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JenkinsHandsOnApplication {

	public static void main(String[] args) {
		SpringApplication.run(JenkinsHandsOnApplication.class, args);
	}

}
