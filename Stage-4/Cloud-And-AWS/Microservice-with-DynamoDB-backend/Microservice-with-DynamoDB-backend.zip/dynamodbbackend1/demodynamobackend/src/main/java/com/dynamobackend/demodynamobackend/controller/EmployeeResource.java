package com.dynamobackend.demodynamobackend.controller;

import com.dynamobackend.demodynamobackend.model.Employee;
import com.dynamobackend.demodynamobackend.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employees")
public class EmployeeResource {
    @Autowired
    private EmployeeRepository employeeRepository;

    @PostMapping
    public Employee addEmployee(@RequestBody Employee employee){
        return employeeRepository.addEmployee(employee);
    }

    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable int id){
        return employeeRepository.findEmployeeById(id);
    }

    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable int id){
        return employeeRepository.deleteEmployee(id);
    }

    @PutMapping
    public String updateEmployee(@RequestBody Employee employee){
        return employeeRepository.editEmployee(employee);
    }
}
