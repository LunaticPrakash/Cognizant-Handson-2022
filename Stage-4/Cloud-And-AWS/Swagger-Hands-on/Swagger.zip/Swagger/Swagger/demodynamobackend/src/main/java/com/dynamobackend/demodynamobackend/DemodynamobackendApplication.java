package com.dynamobackend.demodynamobackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemodynamobackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemodynamobackendApplication.class, args);
	}

}
