package com.dynamobackend.demodynamobackend.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@DynamoDBTable(tableName="Employee")
@ApiModel(description="Employee class which is acting as DTO")
public class Employee {


    @DynamoDBHashKey
    private int id;
    @DynamoDBAttribute
    @ApiModelProperty(notes="Name should contain alphabets")
    private String name;
    @DynamoDBAttribute
    private String gender;
    @DynamoDBAttribute
    @ApiModelProperty(notes="Age should be between 17 and 70")
    private int age;
    @DynamoDBAttribute
    private double salary;


    public int getId() {
        return this.id;
    }
}
