package modify;

public interface IPhone {
	public String GetPhonePart1();
	public double GetPart1Cost();
}
