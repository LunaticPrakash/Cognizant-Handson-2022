package modify;

public class SamsungNote implements IPhone {
	
	public String GetPhonePart1() {
		return "Display";
	}
	
	public double GetPart1Cost() {
		return 500;
	}
}
