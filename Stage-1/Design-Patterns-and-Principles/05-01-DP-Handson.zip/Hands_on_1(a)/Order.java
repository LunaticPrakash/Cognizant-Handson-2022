package design;

public interface Order  {
	void ProcessOrder(String modelName);

	
}
