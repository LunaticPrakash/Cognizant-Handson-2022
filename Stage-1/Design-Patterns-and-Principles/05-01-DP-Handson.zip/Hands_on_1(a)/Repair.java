package design;

public interface Repair  {
	
    void ProcessPhoneRepair(String modelName);

    void ProcessAccessoryRepair(String accessoryType);
}
