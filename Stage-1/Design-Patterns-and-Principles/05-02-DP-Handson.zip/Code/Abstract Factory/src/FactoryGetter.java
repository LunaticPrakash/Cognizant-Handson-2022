
public class FactoryGetter {

	public static Factory getFactory(String type) {

		if (type.equalsIgnoreCase("MERCEDES"))
			return new MercedesFactory();
		else if (type.equalsIgnoreCase("AUDI"))
			return new AudiFactory();
		return null;
	}
}
