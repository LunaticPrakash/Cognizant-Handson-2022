
public class AudiHeadlight extends Headlight {

	public AudiHeadlight() {
		super("Audi Headlight");
	}

}
