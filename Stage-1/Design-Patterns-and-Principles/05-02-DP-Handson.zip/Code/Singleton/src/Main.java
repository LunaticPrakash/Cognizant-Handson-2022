
public class Main {

	public static void main(String[] args) {
		DBConn dbConn = DBConn.getInstance();
		dbConn.display();
	}

}
