package mediator;

public class PremiumUser implements IUser{
	public String name;
	ChatMediator mediator = null;
	
	PremiumUser(String name){
		mediator = new ChatMediator();
		this.name=name;
	}
	public void sendMessage(String message) {
		mediator.sendMessage(name, message);
	}
	
	public void recieveMessage(String name,String message) {
		System.out.println(this.name+" received message from "+name+" : "+message);
	}
}
