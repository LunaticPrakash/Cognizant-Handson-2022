package mediator;

public class BasicUser implements IUser{
	public String name;
	ChatMediator mediator = null;
	
	BasicUser(String name){
		mediator = new ChatMediator();
		this.name=name;
	}
	public void sendMessage(String message) {
		mediator.sendMessage(this.name, message);
	}
	
	public void recieveMessage(String name,String message) {
		System.out.println(this.name+" received message from "+name+" : "+message);
	}
}
