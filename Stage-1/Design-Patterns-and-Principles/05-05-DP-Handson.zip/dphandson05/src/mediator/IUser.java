package mediator;

public interface IUser {
	public void sendMessage(String message);
	public void recieveMessage(String name,String message);
}
