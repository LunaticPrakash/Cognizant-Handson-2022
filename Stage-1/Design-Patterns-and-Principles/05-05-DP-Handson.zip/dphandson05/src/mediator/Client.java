package mediator;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChatMediator mediator = new ChatMediator();
		IUser user1 = new BasicUser("Priya");
		IUser user2 = new BasicUser("Rekha");
		IUser user3 = new BasicUser("Ram");
		IUser user4 = new PremiumUser("Rahul");
		IUser user5 = new PremiumUser("Shree");
		mediator.add(user1);
		mediator.add(user2);
		mediator.add(user3);
		mediator.add(user4);
		user1.sendMessage("Hi All, Wish You Happy Diwali!!");
		
	}

}
