package mediator;

import java.util.ArrayList;
import java.util.List;

public class ChatMediator implements IChatMediator{
	private static ArrayList<IUser> usersList = new ArrayList<IUser>();
	
	ChatMediator(){
	}
	
	
	public void add(IUser user) {
		usersList.add(user);
	}
	
	public void sendMessage(String name,String message) {
		for(IUser u : usersList) {
			u.recieveMessage(name,message);
		}
	}
	
}
