package mediator;

public interface IChatMediator {
	public void add(IUser user);
	public void sendMessage(String name,String message);
}
