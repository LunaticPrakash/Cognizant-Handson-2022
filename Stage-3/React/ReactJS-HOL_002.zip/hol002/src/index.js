import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App.jsx';
import About from './About.jsx';
import Contact from './Contact';

ReactDOM.render(<div><App/> <About/> <Contact/></div>,document.getElementById('root'));


