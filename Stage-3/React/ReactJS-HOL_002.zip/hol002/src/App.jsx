import React from 'react';
import './index.css';
function App(){
    return (<div>
        <h3 className="heading">Welcome to the Home Page of Student Management Portal</h3>
    </div>);
}

export default App;