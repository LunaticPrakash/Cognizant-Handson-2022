import React,{useState} from 'react';
import './App.css';

function App() {

  const [entry,updateEntry]=useState(0);
  

  function login()
  {
    updateEntry(entry+1);
  }

  const [exit,updateExit]=useState(0);
  function leave()
  {
    updateExit(exit+1);
  }

  return (
    <div className="container mt-5">
      <div className="container mt-5">
        <button onClick={login} class="btn btn-success">Login</button>
        <p>{entry} People Entered!!!</p>
      </div>
      <div className="container mt-5">
        <button onClick={leave} class="btn btn-success">Exit</button>
        <p>{exit} People Left!!!</p>
      </div>
    </div>
  );
}

export default App;
