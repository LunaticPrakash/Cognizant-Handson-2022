
const houseList=[
    {
        source:"",
        name:"dbs",
        rent:5000,
        address:"Chennai"
    },
    {
        source:"",
        name:"qbs",
        rent:6000,
        address:"Banglore"
    },
    {
        source:"",
        name:"beta",
        rent:10000,
        address:"Bhopal"
    },
    {
        source:"",
        name:"alpha",
        rent:9000,
        address:"Delhi"
    },
    {
        source:"",
        name:"gamma",
        rent:80000,
        address:"Jalandhar"
    }
    
];
export default houseList;