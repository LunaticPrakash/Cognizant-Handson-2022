import React from 'react';
import './App.css';
import Card from './Card.js';
import houseList from './Houses.jsx'
function App() {
  return (
    <div>
      <h1 className="container">Offfice Space, at Affordable Range</h1>
      <Card item={houseList}/>
    </div>
  );
}

export default App;
