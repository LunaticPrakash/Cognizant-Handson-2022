import React,{useState} from 'react';
function Card()
{
    const [plus,updateNumber] =useState(0);

    function increase()
    {
        updateNumber(plus+1);
    }
    
    function decrease()
    {
        updateNumber(plus-1);
    }
    function hello()
    {
        alert("Hello");
    }
    function click()
    {
        alert("I was Clicked");
    }
    return (
        <div>
        {plus}
        <br></br>
        <br></br>
        <button onClick={increase}>Increment</button>
        <br></br>
        <button onClick={decrease}>Decrement</button>
        <br></br>
        <button onClick={hello}>Say Hello</button>
        <br></br>
        <button onClick={click}>I was Clicked</button>
        </div>
    );
}

export default Card;