
import './App.css';
import Cards from './Card.jsx';
import CurrencyConverter from './CurrencyConverter.jsx';
function App() {
  return(
    <div>
     <Cards />
     <CurrencyConverter />
    </div>
  );
}

export default App;
