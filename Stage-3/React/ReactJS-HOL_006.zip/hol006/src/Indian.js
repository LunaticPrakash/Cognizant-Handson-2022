import React from 'react';
function Indian()
{
    return (
        <div>
            <h1>List of Indian Players Merged</h1>
            <li>Mr.First Player</li>
            <li>Mr.Second Player</li>
            <li>Mr.Third Player</li>
            <li>Mr.Fourth Player</li>
            <li>Mr.Fifth Player</li>
            <li>Mr.Sixth Player</li>
        </div>
    )
}

export default Indian;