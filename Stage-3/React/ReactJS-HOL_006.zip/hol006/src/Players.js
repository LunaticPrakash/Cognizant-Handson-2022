import React from 'react';
import App from './App';
import Even from './Even';
import Less from './Less.jsx';
import Odd from  './Odd';
import Indian from './Indian'
function Players(){
const List=[
    {playername:" Jack",Score:50},
    {playername:" Michael",Score:70},
    {playername:" John",Score:40},
    {playername:" Ann",Score:61},
    {playername:" Elizabeth",Score:61},
    {playername:" Sachin",Score:95},
    {playername:" Dhoni",Score:100},
    {playername:" Virat",Score:84},
    {playername:" jadeja",Score:64},
    {playername:" Raina",Score:75},
    {playername:" Rohit",Score:80}
]

    return (
        <div>
          <App item={List}/>
          <Less item={List}/>
          <Odd/>
          <Even/>
          <Indian />
        </div>
    )

}

export default Players;