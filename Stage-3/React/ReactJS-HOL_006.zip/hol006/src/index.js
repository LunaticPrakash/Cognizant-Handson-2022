import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Players from './Players.js'

ReactDOM.render(<Players />,document.getElementById('root'));
