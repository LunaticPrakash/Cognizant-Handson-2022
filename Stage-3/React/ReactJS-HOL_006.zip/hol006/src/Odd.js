import React from 'react';
function Odd()
{
    return (<div>
        <h1>Odd Players</h1>
        <li>First:Sachin1</li>
        <li>Third:Virat3</li>
        <li>Fifth:Yuvraj5</li>
    </div>)
}
export default Odd;